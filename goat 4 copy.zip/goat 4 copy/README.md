# 🚀 Helper

**AI-powered test question solver with screenshot analysis using Gemini 2.5 Flash**

Solve SAT, Physics, APES, AP Economics, and general test questions instantly by taking screenshots and letting AI analyze them for you.

## ✨ Features

- **📸 Screenshot Analysis**: Take screenshots of test questions and get instant AI-powered solutions
- **🎯 Multiple Test Types**: Support for SAT, Physics, APES, AP Economics, and General questions
- **⌨️ Auto-Typing**: Automatically type FRQ answers into text boxes
- **⏸️ Pause/Resume**: Control typing with pause and resume functionality
- **🔑 Easy Setup**: Simple configuration with API key management

## 🚀 Quick Start

**Super Simple - Just Run and Enter API Key!**

1. **Run the helper:**
   - **Mac/Linux**: Double-click `help` or run `./help`
   - **Windows**: Double-click `help.bat`
2. **Enter your Google AI Studio API key** when prompted
3. **That's it!** Start taking screenshots and solving questions

**Get your free API key at [aistudio.google.com](https://aistudio.google.com/app/apikey)**

## 🎮 Controls

- **Ctrl+M** - Take screenshot
- **Ctrl+U** - Process as Multiple Choice Question (MCQ)
- **Ctrl+F** - Process as Free Response Question (FRQ)
- **Ctrl+T** - Start typing FRQ answer (pause/resume if already typing)
- **Ctrl+P** - Pause/Resume typing
- **Ctrl+C** - Clear screenshots
- **Ctrl+Q** - Quit application

## 📋 Workflow

### For Multiple Choice Questions (MCQ)
1. Take screenshots with **Ctrl+M**
2. Process with **Ctrl+U**
3. Mouse automatically snaps to the correct answer position
4. Click to select the answer

### For Free Response Questions (FRQ)
1. Take screenshots with **Ctrl+M**
2. Process with **Ctrl+F**
3. Mouse moves to bottom right when ready
4. Click in the text box where you want to type
5. Press **Ctrl+T** to auto-type the answer
6. Use **Ctrl+P** to pause/resume typing if needed

## 🛠️ Troubleshooting

**"No API key found"**
- Run the helper again and enter your API key when prompted

**"Node.js version 18+ is required"**
- Update Node.js from [nodejs.org](https://nodejs.org/)

**Screenshots not working**
- Check system permissions for screen recording
- On macOS: System Preferences > Security & Privacy > Screen Recording

**Keyboard listener permission error**
- Run: `./fix-permissions.sh` (Mac/Linux)
- Or manually: `chmod +x node_modules/node-global-key-listener/bin/MacKeyServer`
- Then restart the application

**Typing not working**
- Ensure the text box is focused before pressing Ctrl+T

## 🔒 Privacy & Security

- All data is stored locally on your machine
- No data collection or transmission
- API key stored locally in `config.json`
- Screenshots automatically cleaned up after processing

---

**Made with ❤️ for students everywhere**