#!/bin/bash

# Fix permissions for Helper
echo "🔧 Fixing permissions for Helper..."

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Fix permissions for node-global-key-listener
if [ -f "node_modules/node-global-key-listener/bin/MacKeyServer" ]; then
    echo "Setting permissions for MacKeyServer..."
    chmod +x "node_modules/node-global-key-listener/bin/MacKeyServer"
    echo "✅ Permissions fixed!"
else
    echo "⚠️ MacKeyServer not found. Make sure dependencies are installed first."
    echo "Run: npm install"
fi

echo ""
echo "🚀 You can now run ./cheat"
