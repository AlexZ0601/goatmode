@echo off
REM Change to the directory where this batch file is located
cd /d "%~dp0"

REM Check if node_modules doesn't exist
if not exist "node_modules" (
    echo 🚀 Installing dependencies...
    echo.
    
    REM Install dependencies with proper permissions
    npm install --unsafe-perm=true --allow-root
    
    echo.
    echo ✅ Dependencies installed!
    echo.
)

REM Always check if config exists and run setup if needed
if not exist "config.json" (
    echo 🚀 First time setup - configuring API key...
    echo.
    
    REM Run setup
    npm run setup
    
    echo.
    echo ✅ Setup complete! Starting Helper...
    echo.
)

echo 🚀 Starting Helper...
node index.mjs
pause
