import { GlobalKeyboardListener } from "node-global-key-listener";
import { exec } from "child_process";
import os from "os";
import robot from "@hurdlegroup/robotjs";
import fs from "fs-extra";
import path from "path";
import OpenAI from "openai";
import { fileURLToPath } from "url";
import readline from "readline";
import chalk from "chalk";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

robot.setMouseDelay(0);
robot.setKeyboardDelay(0);

// === Configuration ===
const CONFIG_FILE = path.join(__dirname, "config.json");
let config = null;
let openaiClient = null;


// === Load configuration ===
async function loadConfig() {
  try {
    if (await fs.pathExists(CONFIG_FILE)) {
      config = await fs.readJson(CONFIG_FILE);
      return true;
    }
  } catch (err) {
    console.log(chalk.yellow("⚠️ Could not load config"));
  }
  return false;
}

// === Initialize Gemini client ===
async function initializeOpenAI() {
  const apiKey = process.env.OPENAI_API_KEY || config?.openaiApiKey;
  if (!apiKey) {
    console.log(chalk.red("❌ No OpenAI API key found."));
    console.log(chalk.yellow("Set OPENAI_API_KEY or run 'npm run setup' to save it in config.json."));
    process.exit(1);
  }

  // SDK can also auto-read env var, but we pass explicitly to support config.json
  openaiClient = new OpenAI({ apiKey });
}


// === Track usage ===
async function trackUsage() {
  if (!config) return;
  
  const today = new Date().toISOString().split('T')[0];
  
  // Reset daily counter if it's a new day
  if (config.lastResetDate !== today) {
    config.usageCount = 0;
    config.lastResetDate = today;
  }
  
  config.usageCount++;
  
  try {
    await fs.writeJson(CONFIG_FILE, config, { spaces: 2 });
  } catch (err) {
    console.log(chalk.yellow("⚠️ Could not save usage data"));
  }
}

// === Show usage stats ===
function showUsageStats() {
  if (!config) return;
  
  console.log(chalk.blue(`\n📊 Usage: ${config.usageCount} requests today`));
}

// === Globals ===
let screenshotPaths = [];
const screenshotAnswerCache = new Map();
let currentMode = null; // 'sat', 'physics', 'apes', 'ap-econ', or 'general'
let cleanupPreference = null; // 'cleanup' or 'save'
let screenshotFolder = null; // folder path for saving screenshots
let isTyping = false;
let typingPaused = false;
let currentTypingTimeout = null;

// === Utility functions ===

async function takeScreenshot() {
  // First, center the mouse
  try {
    const screenSize = robot.getScreenSize();
    robot.moveMouse(screenSize.width / 2, screenSize.height / 2);
    console.log("🖱️ Mouse centered");
  } catch (err) {
    console.log("⚠️ Could not center mouse:", err.message);
  }

  const filePath = path.join(__dirname, `screenshot_${Date.now()}.png`);
  
  // Try multiple screenshot methods for lockdown browser compatibility
  const methods = [];
  
  if (os.platform() === "darwin") {
    methods.push(
      `screencapture -x "${filePath}"`,
      `screencapture -c -x "${filePath}"`,
      `screencapture -T 0 -x "${filePath}"`,
      `osascript -e 'tell application "System Events" to keystroke "3" using {command down, shift down}' && sleep 1 && screencapture -x "${filePath}"`
    );
  } else if (os.platform() === "win32") {
    methods.push(
      `powershell -command "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $width = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Width; $height = [System.Windows.Forms.SystemInformation]::PrimaryMonitorSize.Height; $bmp = New-Object Drawing.Bitmap($width, $height); $graphics = [Drawing.Graphics]::FromImage($bmp); $graphics.CopyFromScreen(0, 0, 0, 0, $bmp.Size); $bmp.Save('${filePath.replace(/\\/g, "/")}', [System.Drawing.Imaging.ImageFormat]::Png); $graphics.Dispose(); $bmp.Dispose()"`
    );
  } else {
    methods.push(
      `import -window root "${filePath}"`,
      `gnome-screenshot -f "${filePath}"`,
      `scrot "${filePath}"`
    );
  }

  // Try each method until one succeeds
  for (let i = 0; i < methods.length; i++) {
    try {
      await new Promise((resolve, reject) => {
        exec(methods[i], (error) => {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
        });
      });
      
      // Check if file was created and has content
      if (await fs.pathExists(filePath)) {
        const stats = await fs.stat(filePath);
        if (stats.size > 0) {
          console.log(`📸 Screenshot ${screenshotPaths.length + 1} taken (method ${i + 1})`);
          screenshotPaths.push(filePath);
          return;
        }
      }
    } catch (err) {
      console.log(`⚠️ Screenshot method ${i + 1} failed:`, err.message);
      continue;
    }
  }
  
  // If all methods failed, log error
  console.log("❌ All screenshot methods failed. Please try again or check your system permissions.");
  throw new Error("Screenshot failed");
}

// === Text typing functionality ===
function typeText(text, delay = 50) {
  // Much faster typing - reduced from 200ms to 50ms base delay
  if (text.length > 500) {
    delay = 80; // Reduced from 300ms to 80ms for long answers
    console.log("📝 Long answer detected, using slightly slower typing speed");
  }
  
  isTyping = true;
  typingPaused = false;
  
  try {
    // Don't clear existing text - just start typing
    console.log("⌨️ Starting to type...");
    
    // Ensure we don't move the mouse or click anything that could interfere
    // Just start typing directly into the focused text box
    typeCharacterByCharacter(text, 0, delay);
    
  } catch (err) {
    console.log("⚠️ Could not type text:", err.message);
    isTyping = false;
  }
}

function typeCharacterByCharacter(text, index, delay) {
  if (index >= text.length || !isTyping) {
    isTyping = false;
    console.log("⌨️ Text typing completed");
    return;
  }
  
  if (typingPaused) {
    // If paused, wait and check again - don't advance index
    currentTypingTimeout = setTimeout(() => {
      typeCharacterByCharacter(text, index, delay);
    }, 50); // Faster pause check
    return;
  }
  
  const char = text[index];
  
  try {
    if (char === '\n') {
      robot.keyTap('enter');
      robot.setKeyboardDelay(100); // Much faster
    } else if (char === '\t') {
      robot.keyTap('tab');
      robot.setKeyboardDelay(50); // Much faster
    } else if (char === ' ') {
      robot.keyTap('space');
      robot.setKeyboardDelay(delay);
    } else {
      // Handle special characters
      if (char === '^') {
        robot.keyTap('6', 'shift');
      } else if (char === '√') {
        robot.typeString('sqrt(');
      } else if (char === 'π') {
        robot.typeString('pi');
      } else if (char === 'θ') {
        robot.typeString('theta');
      } else if (char === 'α') {
        robot.typeString('alpha');
      } else if (char === 'β') {
        robot.typeString('beta');
      } else if (char === 'γ') {
        robot.typeString('gamma');
      } else if (char === 'Δ') {
        robot.typeString('Delta');
      } else if (char === '∑') {
        robot.typeString('sum');
      } else if (char === '∫') {
        robot.typeString('integral');
      } else if (char === '∞') {
        robot.typeString('infinity');
      } else if (char === '±') {
        robot.typeString('+-');
      } else if (char === '≤') {
        robot.typeString('<=');
      } else if (char === '≥') {
        robot.typeString('>=');
      } else if (char === '≠') {
        robot.typeString('!=');
      } else {
        robot.typeString(char);
      }
      
      robot.setKeyboardDelay(delay);
    }
    
    // Much faster delays for punctuation
    if (char === '.' || char === ',' || char === ';' || char === ':' || char === '!') {
      robot.setKeyboardDelay(100); // Reduced from 300ms
    }
    
    // Reduced pause frequency and duration for long text
    if (text.length > 200 && index % 100 === 0 && index > 0) {
      robot.setKeyboardDelay(150); // Reduced from 500ms
    }
    
    // Schedule next character with faster delay
    currentTypingTimeout = setTimeout(() => {
      typeCharacterByCharacter(text, index + 1, delay);
    }, delay);
    
  } catch (err) {
    console.log("⚠️ Error typing character:", err.message);
    isTyping = false;
  }
}

// === Pause/Resume typing ===
function pauseTyping() {
  if (isTyping && !typingPaused) {
    typingPaused = true;
    console.log("⏸️ Typing paused. Press Ctrl+T to resume.");
  }
}

function resumeTyping() {
  if (isTyping && typingPaused) {
    typingPaused = false;
    console.log("▶️ Typing resumed.");
  }
}

function stopTyping() {
  if (isTyping) {
    isTyping = false;
    typingPaused = false;
    if (currentTypingTimeout) {
      clearTimeout(currentTypingTimeout);
      currentTypingTimeout = null;
    }
    console.log("⏹️ Typing stopped.");
  }
}

// === Mode selection ===
async function selectMode() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    console.log("\n🎯 Select Test Mode:");
    console.log("1. SAT");
    console.log("2. Physics (All physics types)");
    console.log("3. APES (AP Environmental Science)");
    console.log("4. AP Economics (Macro & Micro)");
    console.log("5. General (Any question type)");
    console.log("");

    rl.question("Enter your choice (1, 2, 3, 4, or 5): ", async (answer) => {
      rl.close();
      if (answer.trim() === "1") {
        currentMode = "sat";
        console.log("✅ SAT mode selected");
      } else if (answer.trim() === "2") {
        currentMode = "physics";
        console.log("✅ Physics mode selected");
      } else if (answer.trim() === "3") {
        currentMode = "apes";
        console.log("✅ APES mode selected");
      } else if (answer.trim() === "4") {
        currentMode = "ap-econ";
        console.log("✅ AP Economics mode selected");
      } else if (answer.trim() === "5") {
        currentMode = "general";
        console.log("✅ General mode selected");
      } else {
        console.log("❌ Invalid choice. Please restart and select 1, 2, 3, 4, or 5.");
        process.exit(1);
      }
      
      // Ask for cleanup preference
      cleanupPreference = await askCleanupPreference();
      
      // Setup screenshot folder if saving
      if (cleanupPreference === "save") {
        const success = await setupScreenshotFolder();
        if (!success) {
          console.log("⚠️ Failed to create folder, switching to cleanup mode");
          cleanupPreference = "cleanup";
        }
      }
      
      // Show controls
      if (currentMode === "sat") {
        showSATControls();
      } else if (currentMode === "physics") {
        showPhysicsControls();
      } else if (currentMode === "apes") {
        showAPESControls();
      } else if (currentMode === "ap-econ") {
        showAPEconomicsControls();
      } else {
        showGeneralControls();
      }
      
      resolve();
    });
  });
}


function showSATControls() {
  console.log("\n🎧 SAT Question Helper Ready!");
  console.log("Controls:");
  console.log("  Ctrl+M  - Take screenshot");
  console.log("  Ctrl+U  - Process as Multiple Choice Question (MCQ)");
  console.log("  Ctrl+F  - Process as Free Response Question (FRQ)");
  console.log("  Ctrl+C  - Clear screenshots");
  console.log("  Ctrl+Q  - Quit application");
  console.log("\nWorkflow:");
  console.log("  1. Take screenshots with Ctrl+M");
  console.log("  2. Process with Ctrl+U (MCQ) or Ctrl+F (FRQ)");
  console.log("  3. Check console for AI responses");
}

function showPhysicsControls() {
  console.log("\n⚛️ Physics Question Helper Ready!");
  console.log("Controls:");
  console.log("  Ctrl+M  - Take screenshot");
  console.log("  Ctrl+U  - Process as Multiple Choice Question (MCQ)");
  console.log("  Ctrl+F  - Process as Free Response Question (FRQ)");
  console.log("  Ctrl+T  - Start typing FRQ answer (pause/resume if already typing)");
  console.log("  Ctrl+P  - Pause/Resume typing");
  console.log("  Ctrl+C  - Clear screenshots");
  console.log("  Ctrl+Q  - Quit application");
  console.log("\nWorkflow:");
  console.log("  1. Take screenshots with Ctrl+M");
  console.log("  2. Process with Ctrl+U (MCQ) or Ctrl+F (FRQ)");
  console.log("  3. For FRQ: Mouse will move to bottom right when ready");
  console.log("  4. Click in text box, then press Ctrl+T to auto-type answer");
  console.log("  5. Use Ctrl+P to pause/resume typing if needed");
  console.log("  6. Check console for AI responses");
}

function showAPESControls() {
  console.log("\n🌍 AP Environmental Science Question Helper Ready!");
  console.log("Controls:");
  console.log("  Ctrl+M  - Take screenshot");
  console.log("  Ctrl+U  - Process as Multiple Choice Question (MCQ)");
  console.log("  Ctrl+F  - Process as Free Response Question (FRQ)");
  console.log("  Ctrl+T  - Start typing FRQ answer (pause/resume if already typing)");
  console.log("  Ctrl+P  - Pause/Resume typing");
  console.log("  Ctrl+C  - Clear screenshots");
  console.log("  Ctrl+Q  - Quit application");
  console.log("\nWorkflow:");
  console.log("  1. Take screenshots with Ctrl+M");
  console.log("  2. Process with Ctrl+U (MCQ) or Ctrl+F (FRQ)");
  console.log("  3. For FRQ: Mouse will move to bottom right when ready");
  console.log("  4. Click in text box, then press Ctrl+T to auto-type answer");
  console.log("  5. Use Ctrl+P to pause/resume typing if needed");
  console.log("  6. Check console for AI responses");
}

function showAPEconomicsControls() {
  console.log("\n💰 AP Economics Question Helper Ready!");
  console.log("Controls:");
  console.log("  Ctrl+M  - Take screenshot");
  console.log("  Ctrl+U  - Process as Multiple Choice Question (MCQ)");
  console.log("  Ctrl+F  - Process as Free Response Question (FRQ)");
  console.log("  Ctrl+T  - Start typing FRQ answer (pause/resume if already typing)");
  console.log("  Ctrl+P  - Pause/Resume typing");
  console.log("  Ctrl+C  - Clear screenshots");
  console.log("  Ctrl+Q  - Quit application");
  console.log("\nWorkflow:");
  console.log("  1. Take screenshots with Ctrl+M");
  console.log("  2. Process with Ctrl+U (MCQ) or Ctrl+F (FRQ)");
  console.log("  3. For FRQ: Mouse will move to bottom right when ready");
  console.log("  4. Click in text box, then press Ctrl+T to auto-type answer");
  console.log("  5. Use Ctrl+P to pause/resume typing if needed");
  console.log("  6. Check console for AI responses");
}

function showGeneralControls() {
  console.log("\n🌐 General Question Helper Ready!");
  console.log("Controls:");
  console.log("  Ctrl+M  - Take screenshot");
  console.log("  Ctrl+U  - Process as Multiple Choice Question (MCQ)");
  console.log("  Ctrl+F  - Process as Free Response Question (FRQ)");
  console.log("  Ctrl+T  - Start typing FRQ answer (pause/resume if already typing)");
  console.log("  Ctrl+P  - Pause/Resume typing");
  console.log("  Ctrl+C  - Clear screenshots");
  console.log("  Ctrl+Q  - Quit application");
  console.log("\nWorkflow:");
  console.log("  1. Take screenshots with Ctrl+M");
  console.log("  2. Process with Ctrl+U (MCQ) or Ctrl+F (FRQ)");
  console.log("  3. For FRQ: Mouse will move to bottom right when ready");
  console.log("  4. Click in text box, then press Ctrl+T to auto-type answer");
  console.log("  5. Use Ctrl+P to pause/resume typing if needed");
  console.log("  6. Check console for AI responses");
}

// === Prompt templates ===

// SAT Prompts
const SAT_MCQ_PROMPT = `You are answering SAT multiple-choice questions. These are standardized questions where the correct answer can be determined by carefully reasoning only with the information provided in the question, including any captions, diagrams, tables, or answer choices visible. Do not use any outside knowledge.

CRITICAL INSTRUCTIONS:
1. DO NOT look at the answer choices until you have calculated your own answer
2. PRIORITIZE HIGHLIGHTED/SELECTED QUESTIONS - If multiple questions are visible, ONLY answer the highlighted, selected, or active question
3. Do the math/reasoning first, then compare with choices

ANALYSIS PROCESS:
1. Identify the specific question being asked (look for highlighted/selected text)
2. Identify the type of question (math, reading, writing, etc.)
3. Extract all given information from text, diagrams, and data
4. Solve the problem independently using the given information
5. Calculate the answer independently
6. ONLY THEN look at the answer choices and compare

For each question:
- Read the question carefully and identify what is being asked
- Extract all relevant information from the question and any accompanying materials
- Solve the problem step by step
- Show all mathematical or logical steps clearly
- Calculate the answer independently before looking at choices
- Make sure every exponent and subscript is clearly read, and also make sure that if you get an 
swer that isnt a option, you redo the math and figure it out.
Format your response as follows:
QUESTION_IDENTIFIED: [Describe the specific question you're answering, noting any highlighted/selected elements]

QUESTION_TYPE: [Identify the type of question (math, reading comprehension, writing, etc.)]

GIVEN_INFORMATION: [List all information extracted from the question, diagrams, and text]

INDEPENDENT_SOLUTION: [Show your complete solution with all steps]

CALCULATED_ANSWER: [Your final calculated answer]

CHOICE_ANALYSIS: [Analyze each answer choice (A, B, C, D, E) and explain why it matches or doesn't match your calculated answer]

ANSWER: [Letter] - [Full text of the chosen answer option]

CRITICAL: The final answer must be in the exact format "ANSWER: [Letter] - [text]" at the very end. Do not include any other text after this line.`;

const SAT_FRQ_REASONING_PROMPT = `You are the official SAT Free Response Question (FRQ) answer key. Each screenshot contains a standardized SAT FRQ, including any diagrams, tables, equations, and answer choices. 

IMPORTANT: Focus on the highlighted/selected question if multiple questions are visible. Look for any highlighted text, selected areas, or active question indicators.

Your job is to read the question carefully and provide a clear, step-by-step explanation showing exactly how to arrive at the correct answer. Use all relevant information visible in the image and do not rely on any external context. Be extremely careful and accurate. Reference answer choices when useful to narrow down options.`;

const SAT_FRQ_FINAL_ANSWER_PROMPT = `Based on your detailed explanation above, provide only the final answer to each question. If the answer is code, provide only the code as plain text with no formatting. If the answer is a word, number, or sentence, provide just that without any extra comments or explanation.`;

// Physics Prompts
const PHYSICS_MCQ_PROMPT = `You are answering physics multiple-choice questions. These questions can be from any physics level including Physics 1, Physics 2, Physics C Mechanics, or Physics C Electricity & Magnetism.

CRITICAL INSTRUCTIONS:
1. DO NOT look at the answer choices until you have calculated your own answer
2. PRIORITIZE HIGHLIGHTED/SELECTED QUESTIONS - If multiple questions are visible, ONLY answer the highlighted, selected, or active question
3. Do the math first, then compare with choices
4. Automatically determine the appropriate mathematical level needed (algebra vs calculus)

ANALYSIS PROCESS:
1. Identify the specific question being asked (look for highlighted/selected text)
2. Identify the physics concept being tested
3. Extract all given data from graphs, diagrams, and text
4. Apply relevant physics principles and equations
5. Calculate the answer independently using the given data
6. ONLY THEN look at the answer choices and compare

For each question:
- Analyze graphs by reading axes, slopes, areas, and key points
- Use calculus when appropriate (derivatives for rates of change, integrals for areas under curves)
- Consider units and dimensional analysis
- Show all mathematical steps clearly
- Calculate the numerical/analytical answer first
- Automatically choose the right mathematical approach based on the problem complexity
- Make sure every exponent and subscript is clearly read, and also make sure that if you get an answer that isn't an option, you redo the math and figure it out.

Format your response as follows:
QUESTION_IDENTIFIED: [Describe the specific question you're answering, noting any highlighted/selected elements]

PHYSICS_CONCEPT: [Identify the physics concept being tested]

GIVEN_DATA: [List all data extracted from graphs, diagrams, and text]

INDEPENDENT_CALCULATION: [Show your complete mathematical solution with all steps]

CALCULATED_ANSWER: [Your final calculated answer with units]

CHOICE_ANALYSIS: [Analyze each answer choice (A, B, C, D, E) and explain why it matches or doesn't match your calculated answer]

ANSWER: [Letter] - [Full text of the chosen answer option]

CRITICAL: The final answer must be in the exact format "ANSWER: [Letter] - [text]" at the very end. Do not include any other text after this line.`;

const PHYSICS_FRQ_REASONING_PROMPT = `You are the official physics Free Response Question (FRQ) answer key. Each screenshot contains a standardized physics FRQ that may include:

1. Graphs to analyze or draw
2. Experimental setups and data
3. Mathematical derivations
4. Conceptual explanations
5. Problem-solving (automatically determine if algebra or calculus is needed)

IMPORTANT: Focus on the highlighted/selected question if multiple questions are visible. Look for any highlighted text, selected areas, or active question indicators.

Your job is to provide a comprehensive, step-by-step solution that includes:
- Clear identification of the physics concept
- Analysis of any given graphs or data
- Proper use of mathematics (automatically choose algebra or calculus as appropriate)
- Correct application of physics equations
- Clear mathematical work
- Proper units and significant figures
- If asked to draw a graph, provide detailed instructions for the graph

Use all relevant information visible in the image. Be extremely careful and accurate with physics principles and mathematical work.`;

const PHYSICS_FRQ_FINAL_ANSWER_PROMPT = `Based on your detailed explanation above, provide the final answer(s) to each question part. Format as follows:

For numerical answers: Just the number with proper units
For algebraic answers: The equation or expression
For graph descriptions: Provide extremely detailed instructions for drawing the graph including:
  - Axes labels and units
  - Scale and range for each axis
  - Key points and their exact coordinates
  - Shape and slope characteristics at different regions
  - Any asymptotes, intercepts, or special features
  - Curve behavior (increasing, decreasing, constant)
  - Any discontinuities or sharp changes
For explanations: Clear, concise physics explanations
For visual descriptions: Describe any diagrams, setups, or visual elements in complete detail

If multiple parts, number them clearly (a), (b), (c), etc.`;

// APES Prompts
const APES_MCQ_PROMPT = `You are answering AP Environmental Science multiple-choice questions. These questions test understanding of environmental science concepts including ecosystems, biodiversity, pollution, climate change, energy, and sustainability.

CRITICAL INSTRUCTIONS:
1. DO NOT look at the answer choices until you have determined your own answer
2. PRIORITIZE HIGHLIGHTED/SELECTED QUESTIONS - If multiple questions are visible, ONLY answer the highlighted, selected, or active question
3. Think through the environmental science concept first, then compare with choices
4. Use specific environmental science terminology and concepts

ANALYSIS PROCESS:
1. Identify the specific question being asked (look for highlighted/selected text)
2. Identify the environmental science concept being tested
3. Extract all given information from graphs, diagrams, data tables, and text
4. Apply relevant environmental science principles and knowledge
5. Determine the answer independently using environmental science concepts
6. ONLY THEN look at the answer choices and compare

For each question:
- Analyze graphs by reading axes, trends, and key data points
- Consider cause-and-effect relationships in environmental systems
- Apply knowledge of environmental laws, cycles, and processes
- Consider both local and global environmental impacts
- Use proper environmental science terminology
- Consider multiple perspectives (ecological, economic, social)
- Show your reasoning process clearly

Format your response as follows:
QUESTION_IDENTIFIED: [Describe the specific question you're answering, noting any highlighted/selected elements]

ENVIRONMENTAL_CONCEPT: [Identify the environmental science concept being tested]

GIVEN_INFORMATION: [List all information extracted from graphs, diagrams, data, and text]

ENVIRONMENTAL_REASONING: [Show your complete reasoning process using environmental science principles]

DETERMINED_ANSWER: [Your final determined answer with environmental science justification]

CHOICE_ANALYSIS: [Analyze each answer choice (A, B, C, D, E) and explain why it matches or doesn't match your determined answer]

ANSWER: [Letter] - [Full text of the chosen answer option]

CRITICAL: The final answer must be in the exact format "ANSWER: [Letter] - [text]" at the very end. Do not include any other text after this line.`;

const APES_FRQ_REASONING_PROMPT = `You are the official AP Environmental Science Free Response Question (FRQ) answer key. Each screenshot contains a standardized AP Environmental Science FRQ that may include:

1. Data analysis and interpretation
2. Environmental problem-solving scenarios
3. Ecological relationships and processes
4. Environmental policy and law applications
5. Sustainability and conservation strategies
6. Climate change and pollution analysis
7. Energy and resource management
8. Population and urbanization impacts

IMPORTANT: Focus on the highlighted/selected question if multiple questions are visible. Look for any highlighted text, selected areas, or active question indicators.

Your job is to provide a comprehensive, step-by-step solution that includes:
- Clear identification of the environmental science concept
- Analysis of any given data, graphs, or environmental scenarios
- Proper application of environmental science principles and laws
- Consideration of ecological, economic, and social factors
- Use of specific environmental science terminology
- Clear reasoning and explanation
- If asked to draw a graph, provide detailed instructions for the graph
- Consider both short-term and long-term environmental impacts

Use all relevant information visible in the image. Be extremely careful and accurate with environmental science principles and terminology.`;

const APES_FRQ_FINAL_ANSWER_PROMPT = `Based on your detailed explanation above, provide the final answer(s) to each question part. Format as follows:

For numerical answers: Just the number with proper units if applicable
For calculations: Show the complete calculation with units
For explanations: Use specific environmental science terminology and concepts
For data analysis: Provide clear interpretation of trends and patterns
For graph descriptions: Provide extremely detailed instructions for drawing the graph including:
  - Axes labels and units
  - Scale and range for each axis
  - Key points and their exact coordinates
  - Shape and slope characteristics at different regions
  - Any asymptotes, intercepts, or special features
  - Curve behavior (increasing, decreasing, constant)
  - Any discontinuities or sharp changes
For policy recommendations: Provide specific, actionable environmental solutions
For environmental impacts: Consider both positive and negative effects
For sustainability solutions: Include specific strategies and their benefits

If multiple parts, number them clearly (a), (b), (c), etc.`;

// AP Economics Prompts
const AP_ECON_MCQ_PROMPT = `You are answering AP Economics multiple-choice questions. These questions can be from either AP Macroeconomics or AP Microeconomics and test understanding of economic principles, concepts, and applications.

CRITICAL INSTRUCTIONS:
1. DO NOT look at the answer choices until you have determined your own answer
2. PRIORITIZE HIGHLIGHTED/SELECTED QUESTIONS - If multiple questions are visible, ONLY answer the highlighted, selected, or active question
3. Think through the economic concept first, then compare with choices
4. Use specific economic terminology and concepts
5. Apply appropriate economic models and theories

ANALYSIS PROCESS:
1. Identify the specific question being asked (look for highlighted/selected text)
2. Identify the economic concept being tested (macro or micro)
3. Extract all given information from graphs, data tables, and text
4. Apply relevant economic principles and models
5. Determine the answer independently using economic reasoning
6. ONLY THEN look at the answer choices and compare

For each question:
- Analyze graphs by reading axes, curves, and key points
- Apply appropriate economic models (supply/demand, AD/AS, etc.)
- Consider both short-run and long-run effects
- Use proper economic terminology
- Consider market structures and economic systems
- Apply cost-benefit analysis where relevant
- Show your reasoning process clearly

Format your response as follows:
QUESTION_IDENTIFIED: [Describe the specific question you're answering, noting any highlighted/selected elements]

ECONOMIC_CONCEPT: [Identify the economic concept being tested and whether it's macro or micro]

GIVEN_INFORMATION: [List all data extracted from graphs, tables, and text]

ECONOMIC_REASONING: [Show your complete economic analysis and reasoning]

DETERMINED_ANSWER: [Your final determined answer based on economic principles]

CHOICE_ANALYSIS: [Analyze each answer choice (A, B, C, D, E) and explain why it matches or doesn't match your determined answer]

ANSWER: [Letter] - [Full text of the chosen answer option]

CRITICAL: The final answer must be in the exact format "ANSWER: [Letter] - [text]" at the very end. Do not include any other text after this line.`;

const AP_ECON_FRQ_REASONING_PROMPT = `You are the official AP Economics Free Response Question (FRQ) answer key. Each screenshot contains a standardized AP Economics FRQ that may include:

1. Graphs to analyze or draw (supply/demand, AD/AS, production possibilities, etc.)
2. Economic data and calculations
3. Economic explanations and analysis
4. Policy analysis and evaluation
5. Market structure analysis
6. Economic model applications

IMPORTANT: Focus on the highlighted/selected question if multiple questions are visible. Look for any highlighted text, selected areas, or active question indicators.

Your job is to provide a comprehensive, step-by-step solution that includes:
- Clear identification of the economic concept (macro or micro)
- Proper use of economic terminology
- Analysis of any given graphs or data
- Correct application of economic models and theories
- Clear mathematical work for calculations
- Proper labeling of graphs and axes
- Economic reasoning and explanations
- Policy implications where relevant

Use all relevant information visible in the image. Be extremely careful and accurate with economic principles and ensure responses align with AP scoring rubrics.`;

const AP_ECON_FRQ_FINAL_ANSWER_PROMPT = `Based on your detailed explanation above, provide the final answer(s) to each question part. Format as follows:

For numerical answers: Just the number with proper units
For algebraic answers: The equation or expression
For graph descriptions: Provide extremely detailed instructions for drawing the graph including:
  - Axes labels and units
  - Scale and range for each axis
  - Key points and their exact coordinates
  - Shape and slope characteristics of curves
  - Equilibrium points and their coordinates
  - Shifts and movements of curves
  - Any special features or intersections
For explanations: Clear, concise economic explanations using proper terminology
For policy analysis: Specific policy recommendations with economic justification

If multiple parts, number them clearly (a), (b), (c), etc.`;

// General Prompts
const GENERAL_MCQ_PROMPT = `Answer this multiple-choice question accurately and quickly.

Instructions:
1. Read the question carefully
2. Think through the answer independently
3. Compare with the choices
4. Select the best answer

Format your response as:
QUESTION: [Brief description of what's being asked]
REASONING: [Your quick reasoning process]
ANSWER: [Letter] - [Full text of chosen option]

CRITICAL: End with "ANSWER: [Letter] - [text]" format.`;

const GENERAL_FRQ_REASONING_PROMPT = `Answer this free response question clearly and concisely.

Instructions:
- Identify what's being asked
- Use all given information
- Provide clear reasoning
- Show work if mathematical
- Be accurate and complete

Focus on the highlighted/selected question if multiple are visible.`;

const GENERAL_FRQ_FINAL_ANSWER_PROMPT = `Provide the final answer(s) concisely:

- Numbers: Include units if applicable
- Equations: Just the expression
- Explanations: Clear and brief
- Code: Plain text only
- Graphs: Basic instructions with key points
- Multiple parts: Number as (a), (b), (c), etc.`;

// === Gemini MCQ call ===
async function askOpenAIMCQ(imagePaths) {
  const hashKey = imagePaths.join(",");
  if (screenshotAnswerCache.has(hashKey)) {
    console.log("⚡ Returning cached OpenAI MCQ result.");
    return screenshotAnswerCache.get(hashKey);
  }

  // Build prompt
  let prompt;
  if (currentMode === "sat") prompt = SAT_MCQ_PROMPT;
  else if (currentMode === "physics") prompt = PHYSICS_MCQ_PROMPT;
  else if (currentMode === "apes") prompt = APES_MCQ_PROMPT;
  else if (currentMode === "ap-econ") prompt = AP_ECON_MCQ_PROMPT;
  else prompt = GENERAL_MCQ_PROMPT;

  // Build multimodal content: text + images
  const content = [{ type: "input_text", text: prompt }];

  for (const imagePath of imagePaths) {
    const imageBuffer = await fs.readFile(imagePath);
    const imageBase64 = imageBuffer.toString("base64");
    content.push({
      type: "input_image",
      image_url: `data:image/png;base64,${imageBase64}`,
    });
  }

  try {
    const model = config?.openaiModel || "gpt-4.1-mini";

    const resp = await openaiClient.responses.create({
      model,
      input: [{ role: "user", content }],
    }); 

    


    const answerText = (resp.output_text || "").trim();

    // Track usage (local counter only; not OpenAI quota)
    await trackUsage();

    // Reuse your existing extraction logic unchanged:
    console.log(`\n🧠 === DETAILED ${currentMode.toUpperCase()} ANALYSIS ===`);
    // (keep your regex printing as-is — it will print whatever tags the model outputs)

    const answerMatches = [...answerText.matchAll(/ANSWER:\s*([A-E])\s*-?\s*(.*)/gi)];
    if (answerMatches.length > 0) {
      const lastMatch = answerMatches[answerMatches.length - 1];
      const letter = lastMatch[1];
      const optionText = lastMatch[2].trim();

      console.log("✅ FINAL ANSWER:");
      console.log(`${letter} - ${optionText}`);
      console.log("=====================================\n");

      const result = {
        letter,
        optionText,
        fullResponse: answerText,
        displayAnswer: `${letter}${optionText ? " - " + optionText : ""}`,
      };
      screenshotAnswerCache.set(hashKey, result);
      return result;
    }

    // Fallback letter extraction
    const lines = answerText.split("\n");
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i].trim();
      const letterMatch = line.match(/\b([A-E])\b/);
      if (letterMatch) {
        const result = {
          letter: letterMatch[0],
          optionText: "",
          fullResponse: answerText,
          displayAnswer: letterMatch[0],
        };
        return result;
      }
    }

    console.log("❌ Could not extract answer from response:");
    console.log(answerText);
    return null;
  } catch (err) {
    console.error("OpenAI MCQ error:", err);
    return null;
  }
}


// === Gemini FRQ call ===
async function askOpenAIFRQ(imagePaths) {
  const hashKey = imagePaths.join(",");
  if (screenshotAnswerCache.has(hashKey)) {
    console.log("⚡ Returning cached OpenAI FRQ result.");
    return screenshotAnswerCache.get(hashKey);
  }

  let reasoningPrompt, answerPrompt;
  if (currentMode === "sat") {
    reasoningPrompt = SAT_FRQ_REASONING_PROMPT;
    answerPrompt = SAT_FRQ_FINAL_ANSWER_PROMPT;
  } else if (currentMode === "physics") {
    reasoningPrompt = PHYSICS_FRQ_REASONING_PROMPT;
    answerPrompt = PHYSICS_FRQ_FINAL_ANSWER_PROMPT;
  } else if (currentMode === "apes") {
    reasoningPrompt = APES_FRQ_REASONING_PROMPT;
    answerPrompt = APES_FRQ_FINAL_ANSWER_PROMPT;
  } else if (currentMode === "ap-econ") {
    reasoningPrompt = AP_ECON_FRQ_REASONING_PROMPT;
    answerPrompt = AP_ECON_FRQ_FINAL_ANSWER_PROMPT;
  } else {
    reasoningPrompt = GENERAL_FRQ_REASONING_PROMPT;
    answerPrompt = GENERAL_FRQ_FINAL_ANSWER_PROMPT;
  }

  const buildContent = async (promptText) => {
    const content = [{ type: "input_text", text: promptText }];
    for (const imagePath of imagePaths) {
      const imageBuffer = await fs.readFile(imagePath);
      const imageBase64 = imageBuffer.toString("base64");
      content.push({
        type: "input_image",
        image_url: `data:image/png;base64,${imageBase64}`,
      });
    }
    return content;
  };

  try {
    const model = config?.openaiModel || "gpt-4.1-mini";

    const reasoningResp = await openaiClient.responses.create({
      model,
      input: [{ role: "user", content: await buildContent(reasoningPrompt) }],
    });
    const reasoning = (reasoningResp.output_text || "").trim();

    const answerResp = await openaiClient.responses.create({
      model,
      input: [{ role: "user", content: await buildContent(answerPrompt) }],
    });
    const answer = (answerResp.output_text || "").trim();

    console.log(`✅ FRQ Answer: ${answer.substring(0, 100)}${answer.length > 100 ? "..." : ""}`);

    // Local tracking
    await trackUsage();
    await trackUsage();

    const result = { reasoning, answer };
    if (answer) screenshotAnswerCache.set(hashKey, result);
    return result;
  } catch (err) {
    console.error("OpenAI FRQ error:", err);
    return null;
  }
}

// === Mouse positioning for answers ===
function snapToAnswer(letter) {
  try {
    const { width, height } = robot.getScreenSize();
    let x, y;
    
    switch (letter.toUpperCase()) {
      case 'A':
        // Far left corner (top left)
        x = 10;
        y = 10;
        break;
      case 'B':
        // Top right corner
        x = width - 10;
        y = 10;
        break;
      case 'C':
        // Bottom left corner
        x = 10;
        y = height - 10;
        break;
      case 'D':
        // Bottom right corner
        x = width - 10;
        y = height - 10;
        break;
      case 'E':
        if (currentMode === "physics") {
          // For Physics C, snap to very bottom center of screen
          x = width / 2;
          y = height - 10;
        } else {
          // For SAT, slightly lower than middle
          x = width / 2;
          y = (height / 2) + 50;
        }
        break;
      default:
        console.log(`❌ Unknown answer letter: ${letter}`);
        return;
    }
    
    robot.moveMouse(x, y);
    console.log(`🎯 Snapped to ${letter}`);
  } catch (err) {
    console.log(`⚠️ Could not snap to ${letter}`);
  }
}

// === Move mouse to indicate FRQ ready ===
function indicateFRQReady() {
  try {
    const { width, height } = robot.getScreenSize();
    // Move to bottom right corner to indicate FRQ is ready
    robot.moveMouse(width - 10, height - 10);
    console.log("🎯 Mouse moved to bottom right - FRQ ready for typing! Press Ctrl+T to start typing.");
    console.log("💡 Click in the text box first, then press Ctrl+T to start typing.");
  } catch (err) {
    console.log("⚠️ Could not move mouse to indicate FRQ ready");
  }
}

// === Clean up old screenshots ===
async function cleanupScreenshots() {
  for (const filepath of screenshotPaths) {
    try {
      await fs.remove(filepath);
    } catch (err) {
      console.error("Failed to cleanup:", filepath, err);
    }
  }
  screenshotPaths = [];
}

// === Save screenshots to folder ===
async function saveScreenshots() {
  try {
    for (const filepath of screenshotPaths) {
      const filename = path.basename(filepath);
      const newPath = path.join(screenshotFolder, filename);
      await fs.move(filepath, newPath);
    }
    
    console.log(`💾 Saved to: ${path.basename(screenshotFolder)}`);
    screenshotPaths = [];
  } catch (err) {
    console.error("Failed to save screenshots:", err);
  }
}

// === Ask for cleanup preference ===
async function askCleanupPreference() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    console.log("\n🗑️ What would you like to do with screenshots during this session?");
    console.log("1. Clean up (delete) screenshots after each question");
    console.log("2. Save screenshots to folder after each question");
    console.log("");

    rl.question("Enter your choice (1 or 2): ", (answer) => {
      rl.close();
      if (answer.trim() === "1") {
        resolve("cleanup");
      } else if (answer.trim() === "2") {
        resolve("save");
      } else {
        console.log("❌ Invalid choice. Defaulting to cleanup.");
        resolve("cleanup");
      }
    });
  });
}

// === Setup screenshot folder ===
async function setupScreenshotFolder() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const folderName = `screenshots_${currentMode}_${timestamp}`;
  screenshotFolder = path.join(__dirname, folderName);
  
  try {
    await fs.ensureDir(screenshotFolder);
    console.log(`📁 Created folder: ${folderName}`);
    return true;
  } catch (err) {
    console.error("Failed to create screenshot folder:", err);
    return false;
  }
}

// === Main keyboard listener ===
let v = null;

try {
  v = new GlobalKeyboardListener();
} catch (err) {
  console.log(chalk.red("❌ Keyboard listener failed to initialize:"));
  console.log(chalk.yellow("This is likely due to permission issues with the global key listener."));
  console.log(chalk.blue("\n🔧 To fix this, run the following command in Terminal:"));
  console.log(chalk.white("sudo chmod +x node_modules/node-global-key-listener/bin/MacKeyServer"));
  console.log(chalk.gray("\nThen restart the application."));
  console.log(chalk.gray("\nAlternatively, you can run the application with sudo (not recommended):"));
  console.log(chalk.white("sudo ./cheat"));
  process.exit(1);
}

v.addListener(async function (e, down) {
  const ctrl = down["LEFT CTRL"] || down["RIGHT CTRL"];
  const key = e.name;

  if (e.state === "DOWN" && ctrl) {
    if (key === "M") {
      // Take screenshot
      try {
        await takeScreenshot();
      } catch (err) {
        console.log("❌ Screenshot failed. Please try again or check your system permissions.");
      }
    } else if (key === "U") {
      // Process as Multiple Choice Question
      if (screenshotPaths.length === 0) {
        console.log("⚠️ No screenshots taken for MCQ.");
        return;
      }

      console.log(`🔍 Processing ${currentMode.toUpperCase()} MCQ...`);
      const result = await askOpenAIMCQ(screenshotPaths);
      
      if (!result) {
        console.log("⚠️ No answer returned.");
      } else {
        // Snap mouse to the answer position (only once)
        snapToAnswer(result.letter);
      }
      

      if (!result) {
        console.log("⚠️ No answer returned.");
        return;
      }

// wherever you previously used geminiResult.letter / displayAnswer:
      console.log("✅ Answer:", result.displayAnswer || result.letter);

// if you auto-type:
      


      // Handle screenshots based on session preference
      if (cleanupPreference === "cleanup") {
        await cleanupScreenshots();
      } else {
        await saveScreenshots();
      }
    } else if (key === "F") {
      // Process as Free Response Question
      if (screenshotPaths.length === 0) {
        console.log("⚠️ No screenshots taken for FRQ.");
        return;
      }

      console.log(`🔍 Processing ${currentMode.toUpperCase()} FRQ...`);
      const result = await askOpenAIFRQ(screenshotPaths);


      if (!result) {
        console.log("⚠️ No answer returned.");
      } else {
        if (currentMode === "physics" || currentMode === "apes" || currentMode === "ap-econ" || currentMode === "general") {
          console.log("⌨️ Ready to type. Click in text box, then press Ctrl+T");
          // Move mouse to bottom right to indicate FRQ is ready
          indicateFRQReady();
        }
      }

      // Handle screenshots based on session preference
      if (cleanupPreference === "cleanup") {
        await cleanupScreenshots();
      } else {
        await saveScreenshots();
      }
    } else if (key === "T" && (currentMode === "physics" || currentMode === "apes" || currentMode === "ap-econ" || currentMode === "general")) {
      // Type the last FRQ answer (Physics, APES, and General modes)
      if (isTyping) {
        if (typingPaused) {
          resumeTyping();
        } else {
          pauseTyping();
        }
      } else {
        const lastResult = Array.from(screenshotAnswerCache.values()).pop();
        if (lastResult && lastResult.answer) {
          console.log("⌨️ Typing answer...");
          console.log("⏳ Waiting 1 second before typing to ensure text box is ready...");
          console.log("💡 Make sure the text box is focused before typing starts!");
          
          // Wait a moment to ensure the text box is ready
          setTimeout(() => {
            typeText(lastResult.answer);
          }, 1000);
        } else {
          console.log("⚠️ No answer available to type. Process an FRQ first with Ctrl+F.");
        }
      }
    } else if (key === "P") {
      // Pause/Resume typing
      if (isTyping) {
        if (typingPaused) {
          resumeTyping();
        } else {
          pauseTyping();
        }
      } else {
        // Check if there's an FRQ answer ready to type
        const lastResult = Array.from(screenshotAnswerCache.values()).pop();
        if (lastResult && lastResult.answer) {
          console.log("⌨️ Starting to type FRQ answer...");
          console.log("⏳ Waiting 1 second before typing to ensure text box is ready...");
          
          // Wait a moment to ensure the text box is ready
          setTimeout(() => {
            typeText(lastResult.answer);
          }, 1000);
        } else {
          console.log("⚠️ No typing in progress and no FRQ answer available. Use Ctrl+F to process an FRQ first.");
        }
      }
    } else if (key === "C") {
      // Clear screenshots without processing
      console.log("🗑️ Clearing screenshots...");
      await cleanupScreenshots();
    } else if (key === "Q") {
      // Quit application
      console.log("👋 Exiting application...");
      await cleanupScreenshots();
      process.exit(0);
    }
  }
});

// === Main execution ===
async function main() {
  console.log(chalk.blue.bold("\n🚀 Helper v2.0"));
  console.log(chalk.gray("AI-powered test question solver with OpenAI (Responses API)\n"));


  
  // Load configuration
  const configLoaded = await loadConfig();
  if (!configLoaded) {
    console.log(chalk.red("❌ Configuration not found. Please run 'npm run setup' first."));
    process.exit(1);
  }
  
  // Initialize Gemini
  await initializeOpenAI();
  
  // Show usage stats
  showUsageStats();
  
  // Start the application
  await selectMode();
}

main().catch(console.error);