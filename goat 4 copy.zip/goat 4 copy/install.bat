@echo off
REM Change to the directory where this batch file is located
cd /d "%~dp0"

REM Helper Installation Script for Windows
echo 🚀 Helper Installation Script
echo ======================================
echo.

REM Check if Node.js is installed
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Node.js is not installed!
    echo Please install Node.js 18+ from: https://nodejs.org/
    pause
    exit /b 1
)

echo ✅ Node.js version: 
node --version

REM Check if npm is installed
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ npm is not installed!
    echo Please install npm or update Node.js
    pause
    exit /b 1
)

echo ✅ npm version: 
npm --version

REM Install dependencies
echo.
echo 📦 Installing dependencies...
npm install

if %errorlevel% neq 0 (
    echo ❌ Failed to install dependencies!
    echo Please check your internet connection and try again.
    pause
    exit /b 1
)

echo ✅ Dependencies installed successfully!

REM Run setup
echo.
echo 🔧 Running initial setup...
npm run setup

if %errorlevel% neq 0 (
    echo ❌ Setup failed!
    echo Please run 'npm run setup' manually to configure your API key.
    pause
    exit /b 1
)

echo.
echo 🎉 Installation complete!
echo.
echo To start using Helper:
echo   help.bat
echo.
echo To update your API key later:
echo   npm run setup
echo.
echo For help, see README.md
pause
