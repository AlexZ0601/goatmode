#!/bin/bash

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Helper Installation Script
echo "🚀 Helper Installation Script"
echo "======================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js 18+ from: https://nodejs.org/"
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version 18+ is required!"
    echo "Current version: $(node --version)"
    echo "Please update Node.js from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed!"
    echo "Please install npm or update Node.js"
    exit 1
fi

echo "✅ npm version: $(npm --version)"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies!"
    echo "Please check your internet connection and try again."
    exit 1
fi

echo "✅ Dependencies installed successfully!"

# Run setup
echo ""
echo "🔧 Running initial setup..."
npm run setup

if [ $? -ne 0 ]; then
    echo "❌ Setup failed!"
    echo "Please run 'npm run setup' manually to configure your API key."
    exit 1
fi

echo ""
echo "🎉 Installation complete!"
echo ""
echo "To start using Helper:"
echo "  ./help"
echo ""
echo "To update your API key later:"
echo "  npm run setup"
echo ""
echo "For help, see README.md"
