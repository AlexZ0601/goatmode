import fs from "fs-extra";
import path from "path";
import { fileURLToPath } from "url";
import readline from "readline";
import chalk from "chalk";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CONFIG_FILE = path.join(__dirname, "config.json");

// Default config
const defaultConfig = {
  openaiApiKey: "",
  openaiModel: "gpt-5.1", // good default for image+text tasks
  usageCount: 0,
  lastResetDate: new Date().toISOString().split('T')[0],
  version: "2.0.0"
};

async function loadConfig() {
  try {
    if (await fs.pathExists(CONFIG_FILE)) {
      const config = await fs.readJson(CONFIG_FILE);
      return { ...defaultConfig, ...config };
    }
  } catch (err) {
    console.log(chalk.yellow("⚠️ Could not load config, using defaults"));
  }
  return defaultConfig;
}

async function saveConfig(config) {
  try {
    await fs.writeJson(CONFIG_FILE, config, { spaces: 2 });
    return true;
  } catch (err) {
    console.log(chalk.red("❌ Could not save config:", err.message));
    return false;
  }
}

function askQuestion(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

function estimateRemainingRequests(usageCount) {
  return {
    remaining: "unlimited",
    isFreeTier: true,
    percentage: 0
  };
}

async function main() {
  console.log(chalk.blue.bold("\n🚀 Helper Setup"));
  console.log(chalk.gray("Setting up your AI-powered test question solver...\n"));

  // Check Node.js version
  const nodeVersion = process.version;
  const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
  
  if (majorVersion < 18) {
    console.log(chalk.red("❌ Node.js version 18 or higher is required"));
    console.log(chalk.yellow(`Current version: ${nodeVersion}`));
    console.log(chalk.blue("Please update Node.js from: https://nodejs.org/"));
    process.exit(1);
  }

  console.log(chalk.green(`✅ Node.js version: ${nodeVersion}`));

  // Load existing config
  const config = await loadConfig();
  
  // Check if API key is already set
  if (config.geminiApiKey) {
    console.log(chalk.green("✅ Gemini API key already configured"));
    
    // Show usage stats
    const stats = estimateRemainingRequests(config.usageCount);
    console.log(chalk.blue("\n📊 Usage Statistics:"));
    console.log(`   Requests used today: ${config.usageCount}`);
    console.log(`   Remaining (free tier): ${stats.remaining}`);
    console.log(`   Usage percentage: ${stats.percentage}%`);
    
    if (stats.percentage > 80) {
      console.log(chalk.yellow("⚠️ You're approaching the free tier limit!"));
    }
    
    const updateKey = await askQuestion("\n🔄 Do you want to update your API key? (y/N): ");
    if (updateKey.toLowerCase() === 'y' || updateKey.toLowerCase() === 'yes') {
      // Continue to API key setup
    } else {
      console.log(chalk.green("\n✅ Setup complete! Run './cheat' to begin."));
      process.exit(0);
    }
  }

  // API Key setup
    // API Key setup
  console.log(chalk.blue("\n🔑 OpenAI API Key Setup"));
  console.log(chalk.gray("You need an OpenAI API key (API billing is separate from ChatGPT Plus)."));
  console.log(chalk.gray("Recommended: set OPENAI_API_KEY in your terminal, or paste it here.\n"));

  let apiKey = "";
  while (!apiKey) {
    apiKey = await askQuestion("Enter your OpenAI API key (starts with sk-): ");

    if (!apiKey) {
      console.log(chalk.red("❌ API key cannot be empty"));
      continue;
    }

    // Light validation (don’t be too strict; OpenAI has multiple key prefixes)
    if (!apiKey.startsWith("sk-")) {
      console.log(chalk.yellow("⚠️ This doesn’t look like a typical OpenAI key (often starts with 'sk-')."));
      const confirm = await askQuestion("Continue anyway? (y/N): ");
      if (confirm.toLowerCase() !== "y" && confirm.toLowerCase() !== "yes") {
        apiKey = "";
      }
    }
  }

  // Test the API key
  console.log(chalk.blue("\n🧪 Testing API key..."));
  try {
    const OpenAI = (await import("openai")).default;
    const client = new OpenAI({ apiKey });

    const resp = await client.responses.create({
      model: "gpt-5.2", // text-only quick ping
      input: "Say 'ok'."
    });

    if (!resp?.output_text) throw new Error("No output_text returned.");
    console.log(chalk.green("✅ API key is valid!"));
  } catch (err) {
    console.log(chalk.red("❌ API key test failed:", err.message));
    console.log(chalk.yellow("Check billing + key permissions, then try again."));
    process.exit(1);
  }

  // Save config
  config.openaiApiKey = apiKey;
  config.lastResetDate = new Date().toISOString().split('T')[0];

  // Show final instructions
  console.log(chalk.blue.bold("\n🎉 Setup Complete!"));
  console.log(chalk.gray("\nTo start using Helper:"));
  console.log(chalk.white("  npm start"));
  console.log(chalk.gray("\nTo update your API key later:"));
  console.log(chalk.white("  npm run setup"));
  
  console.log(chalk.blue.bold("\n📋 Quick Start Guide:"));
  console.log(chalk.white("1. Take screenshots with Ctrl+M"));
  console.log(chalk.white("2. Process MCQ with Ctrl+U or FRQ with Ctrl+F"));
  console.log(chalk.white("3. For FRQ: Click in text box, then Ctrl+T to auto-type"));
  console.log(chalk.white("4. Use Ctrl+P to pause/resume typing"));
  console.log(chalk.white("5. Press Ctrl+Q to quit"));
}

main().catch(console.error);
